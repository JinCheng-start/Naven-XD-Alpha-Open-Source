package org.msgpack.core.annotations;

public @interface VisibleForTesting {
}
