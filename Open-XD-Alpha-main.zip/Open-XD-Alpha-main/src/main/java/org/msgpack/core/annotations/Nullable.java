package org.msgpack.core.annotations;

public @interface Nullable {
}
