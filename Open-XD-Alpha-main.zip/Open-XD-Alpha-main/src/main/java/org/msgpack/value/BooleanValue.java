package org.msgpack.value;

public interface BooleanValue extends Value {
   boolean getBoolean();
}
