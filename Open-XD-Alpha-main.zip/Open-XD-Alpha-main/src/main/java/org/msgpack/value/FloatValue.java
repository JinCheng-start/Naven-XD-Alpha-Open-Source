package org.msgpack.value;

public interface FloatValue extends NumberValue {
}
