package org.msgpack.value;

public interface ImmutableBinaryValue extends BinaryValue, ImmutableRawValue {
}
