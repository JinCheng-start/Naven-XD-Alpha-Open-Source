package org.msgpack.value;

public interface ImmutableIntegerValue extends IntegerValue, ImmutableNumberValue {
}
