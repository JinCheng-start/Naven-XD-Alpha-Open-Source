package org.msgpack.value;

public interface ImmutableFloatValue extends FloatValue, ImmutableNumberValue {
}
