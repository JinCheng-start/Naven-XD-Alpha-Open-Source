package org.msgpack.value;

public interface ImmutableStringValue extends StringValue, ImmutableRawValue {
}
