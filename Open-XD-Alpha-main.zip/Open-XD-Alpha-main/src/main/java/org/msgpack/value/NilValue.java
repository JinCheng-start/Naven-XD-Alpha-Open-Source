package org.msgpack.value;

public interface NilValue extends Value {
}
