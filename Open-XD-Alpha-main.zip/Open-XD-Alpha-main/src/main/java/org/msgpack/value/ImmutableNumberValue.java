package org.msgpack.value;

public interface ImmutableNumberValue extends NumberValue, ImmutableValue {
}
