package com.heypixel.heypixelmod.exceptions;

public class BadValueTypeException extends RuntimeException {
}
