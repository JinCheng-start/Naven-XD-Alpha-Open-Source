package com.heypixel.heypixelmod.modules.impl.move;

import com.heypixel.heypixelmod.modules.Module;

public class NoSlow extends Module {
   //NoSlow也已被害死
}