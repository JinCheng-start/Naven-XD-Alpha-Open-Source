package com.heypixel.heypixelmod;

public class Constants {
    public static final String MOD_ID = "heypixel";
}