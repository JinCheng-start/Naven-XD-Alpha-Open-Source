package com.heypixel.heypixelmod.events.impl;

import com.heypixel.heypixelmod.events.api.events.callables.EventCancellable;

public class EventAttackSlowdown extends EventCancellable {
}
