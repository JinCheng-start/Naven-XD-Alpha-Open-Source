package com.heypixel.heypixelmod;

public class Version {
    public static String getVersion() {
            return "OpenAlpha";
        }
    }