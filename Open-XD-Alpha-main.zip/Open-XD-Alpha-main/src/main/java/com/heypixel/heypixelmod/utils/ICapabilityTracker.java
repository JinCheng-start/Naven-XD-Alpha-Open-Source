package com.heypixel.heypixelmod.utils;

public interface ICapabilityTracker {
   boolean get();

   void set(boolean var1);
}
