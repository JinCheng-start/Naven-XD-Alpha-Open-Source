package com.heypixel.heypixelmod.events.impl;

import com.heypixel.heypixelmod.events.api.events.callables.EventTyped;

public class EventJoinWorld extends EventTyped {
    public EventJoinWorld(byte eventType) {
        super(eventType);
    }
}