package com.heypixel.heypixelmod.events.api.events;

public interface Cancellable {
   boolean isCancelled();

   void setCancelled(boolean var1);
}
