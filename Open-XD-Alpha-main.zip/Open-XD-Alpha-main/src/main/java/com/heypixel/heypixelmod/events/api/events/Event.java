package com.heypixel.heypixelmod.events.api.events;

public interface Event {
}
