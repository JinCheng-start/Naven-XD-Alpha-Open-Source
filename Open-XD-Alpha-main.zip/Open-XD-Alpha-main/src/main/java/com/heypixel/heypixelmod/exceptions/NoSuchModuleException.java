package com.heypixel.heypixelmod.exceptions;

public class NoSuchModuleException extends RuntimeException {
   public static Object r;
   public static Object s;
}
