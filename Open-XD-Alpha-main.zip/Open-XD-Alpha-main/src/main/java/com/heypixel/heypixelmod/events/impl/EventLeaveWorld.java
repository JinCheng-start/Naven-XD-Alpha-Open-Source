package com.heypixel.heypixelmod.events.impl;

import com.heypixel.heypixelmod.events.api.events.callables.EventTyped;

public class EventLeaveWorld extends EventTyped {
    public EventLeaveWorld(byte eventType) {
        super(eventType);
    }
}