package com.heypixel.heypixelmod.modules.impl.render;

import com.heypixel.heypixelmod.modules.Category;
import com.heypixel.heypixelmod.modules.Module;
import com.heypixel.heypixelmod.modules.ModuleInfo;

@ModuleInfo(
   name = "AntiBlindness",
   description = "Prevents blindness",
   category = Category.RENDER
)
public class AntiBlindness extends Module {
}
