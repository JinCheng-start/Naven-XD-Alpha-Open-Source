package com.heypixel.heypixelmod.modules.impl.crystalpvp;

import com.heypixel.heypixelmod.events.api.EventTarget;
import com.heypixel.heypixelmod.events.api.types.EventType;
import com.heypixel.heypixelmod.events.impl.EventPacket;
import com.heypixel.heypixelmod.modules.Category;
import com.heypixel.heypixelmod.modules.Module;
import com.heypixel.heypixelmod.modules.ModuleInfo;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;

import java.lang.reflect.Field;

@ModuleInfo(
        name = "CrystalOptimizer",
        description = "Does not wait for server-side confirmation when breaking crystals",
        category = Category.CRYSTALPVP
)
public class CrystalOptimizer extends Module {

    @EventTarget
    public void onPacket(EventPacket e) {
        if (e.getType() != EventType.PRE) {
            return;
        }

        Packet<?> packet = e.getPacket();
        if (packet instanceof ServerboundInteractPacket interactPacket) {
            try {
                Field actionField = ServerboundInteractPacket.class.getDeclaredField("action");
                actionField.setAccessible(true);
                Object action = actionField.get(interactPacket);

                Field entityIdField = ServerboundInteractPacket.class.getDeclaredField("entityId");
                entityIdField.setAccessible(true);
                int entityId = entityIdField.getInt(interactPacket);

                Object actionType = action.getClass().getMethod("getType").invoke(action);
                if (actionType.toString().equals("ATTACK")) {
                    Entity entity = mc.level.getEntity(entityId);

                    if (entity instanceof EndCrystal && mc.player.getEffect(MobEffects.WEAKNESS) == null) {
                        entity.kill();
                        entity.setRemoved(Entity.RemovalReason.KILLED);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}