package com.heypixel.heypixelmod.events.api.events;

public interface Typed {
   byte getType();
}
