package com.heypixel.heypixelmod.exceptions;

public class NoSuchValueException extends RuntimeException {
}
