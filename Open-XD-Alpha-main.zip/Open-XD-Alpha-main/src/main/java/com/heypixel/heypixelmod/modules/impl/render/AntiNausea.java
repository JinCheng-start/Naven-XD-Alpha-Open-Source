package com.heypixel.heypixelmod.modules.impl.render;

import com.heypixel.heypixelmod.modules.Category;
import com.heypixel.heypixelmod.modules.Module;
import com.heypixel.heypixelmod.modules.ModuleInfo;

@ModuleInfo(
   name = "AntiNausea",
   description = "Prevents nausea",
   category = Category.RENDER
)
public class AntiNausea extends Module {
}
