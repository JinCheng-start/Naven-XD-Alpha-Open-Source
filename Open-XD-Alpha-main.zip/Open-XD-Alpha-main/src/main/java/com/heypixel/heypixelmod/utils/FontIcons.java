package com.heypixel.heypixelmod.utils;

public class FontIcons {
    public static String CLOCK = "\ue90c";
    public static String CHARTLINE = "\ue90b";
    public static String CLOCKROTATELEFT = "\ue90a";
    public static String USER = "\ue909";
    public static String RETRY = "\ue908";
    public static String ARROWREPLY = "\ue907";
    public static String PEN = "\ue906";
    public static String RESIZE = "\ue905";
    public static String SWORD = "\ue904";
    public static String RUNNING = "\ue903";
    public static String EYE = "\ue902";
    public static String OTHER = "\ue901";
    public static String CRYSTAL = "\ue900";
}
