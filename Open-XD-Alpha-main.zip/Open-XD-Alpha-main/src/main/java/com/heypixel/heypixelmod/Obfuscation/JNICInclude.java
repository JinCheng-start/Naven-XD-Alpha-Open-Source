package com.heypixel.heypixelmod.Obfuscation;

public @interface JNICInclude {
}
