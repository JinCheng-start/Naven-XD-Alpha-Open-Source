package com.heypixel.heypixelmod.values;

public abstract class HasValue {
   private String name;

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }
}
