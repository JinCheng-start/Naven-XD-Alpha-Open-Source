package com.heypixel.heypixelmod.utils.renderer.text;

record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {
}
