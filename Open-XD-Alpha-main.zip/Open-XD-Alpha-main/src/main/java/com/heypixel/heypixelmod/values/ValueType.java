package com.heypixel.heypixelmod.values;

public enum ValueType {
   BOOLEAN,
   FLOAT,
   INTEGER,
   MODE,
   STRING;
}