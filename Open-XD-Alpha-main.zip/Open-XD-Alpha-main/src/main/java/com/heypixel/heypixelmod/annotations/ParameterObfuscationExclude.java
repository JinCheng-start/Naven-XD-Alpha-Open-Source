package com.heypixel.heypixelmod.annotations;

public @interface ParameterObfuscationExclude {
}
