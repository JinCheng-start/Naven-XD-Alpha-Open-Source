# OpenXD-Alpha
A Minecraft Hack Client

**Repository**: [Koplim123/OpenXD-Alpha](https://github.com/Koplim123/OpenXD-Alpha)

A Naven base Minecraft Hacking Client.
Removed some Origin Alpha features and bypass..
